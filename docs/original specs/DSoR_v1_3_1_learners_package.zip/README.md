# DSoR v1.3.1 (Learner's Edition) — specification package

New to this? Open the specification, read **Start here** (15 minutes), then follow **Appendix D**, which builds a small DSoR in five stages. **Appendix E** has questions and answers.

| Path | What it is |
|---|---|
| `DSoR_Specification_v1_3_1_Learners_Edition.md` | The specification. Every section opens in plain words before its rules. Requirements are identical to v1.3 |
| `requirements.json` | Machine-readable registry of every requirement: id, level, section, normative sentence |
| `schemas/*.schema.json` | Normative JSON Schemas (draft 2020-12), Appendix A |
| `examples/*.example.json` | One validated instance per schema, from the specification's running example |
| `tests/test_schemas.py` | Validates every example and checks that 15 invalid variants are rejected |
| `tests/test_control_cel.py` | Runs the `high-value-payment` control's test vectors and the `payment.execute` preconditions through a CEL evaluator |

```bash
pip install jsonschema cel-python
python tests/test_schemas.py
python tests/test_control_cel.py
```

The CEL test registers `dsor_money`, `dsor_exceeds`, and `dsor_covers` as plain extension functions with rates pinned per test vector. It is a check of the specification's examples, not a reference implementation.
