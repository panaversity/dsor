import json, celpy, sys, os
ROOT=os.path.join(os.path.dirname(os.path.abspath(__file__)),"..")
from decimal import Decimal
from celpy import celtypes
from celpy.evaluation import CELEvalError
# reference rate table for the test: units of currency per 1 USD (illustrative fixed values)
RATES={"USD":Decimal(1)}   # a vector that converts must pin its own rates
class Unconvertible(Exception): pass
def conv(m,to):
    c=str(m["currency"]); 
    if c not in RATES or to not in RATES: raise Unconvertible(c)
    return Decimal(str(m["value"]))/RATES[c]*RATES[to]
def money(v,c): return celtypes.MapType({celtypes.StringType("value"):v, celtypes.StringType("currency"):c})
def exceeds(a,b):   # a > b, in b's currency
    return celtypes.BoolType(conv(a,str(b["currency"])) > Decimal(str(b["value"])))
def covers(a,b):    # a >= b, in a's currency
    return celtypes.BoolType(Decimal(str(a["value"])) >= conv(b,str(a["currency"])))
FUN={"dsor_money":money,"dsor_exceeds":exceeds,"dsor_covers":covers}
env=celpy.Environment()
def evaluate(expr, activation):
    # celpy has no namespaced-function support, so the test harness maps dsor.f(...) to dsor_f(...).
    ast=env.compile(expr)
    return env.program(ast,functions=FUN).evaluate(celpy.json_to_cel(activation))
ctl=json.load(open(os.path.join(ROOT,"examples","control.example.json")))
effect="REQUIRE_APPROVAL"
ok=True
for t in ctl["tests"]:
    act={"state":t.get("state",{}),"input":t.get("input",{})}
    RATES.clear(); RATES.update({"USD":Decimal(1)}); RATES.update({k:Decimal(v) for k,v in t.get("rates",{}).items()})
    try:
        r=bool(evaluate(ctl["condition"],act)); note=""
    except (Unconvertible,CELEvalError,KeyError) as e:
        r=True; note=f"  (evaluation failed: {type(e).__name__} → restrictive, DSOR-CTL-07 / DSOR-MON-04)"
    got=effect if r else "ALLOW"
    amt=t["state"]["payment"]["amount"]
    print(f'{("PASS" if got==t["expect"] else "FAIL")}  {amt["value"]:>14} {amt["currency"]}  → {got}{note}'); ok&=got==t["expect"]
# the v1.2 condition, for comparison
old='input.amount.value > 25000.0 && input.amount.currency == "USD"'
RATES['PKR']=Decimal('280')
r=bool(evaluate(old,{"input":{"amount":{"value":50000000.0,"currency":"PKR"}}}))
print("v1.2 condition on 50,000,000 PKR →", "REQUIRE_APPROVAL" if r else "ALLOW  (the hole v1.3 closes)")
# contract predicates parse
oc=json.load(open(os.path.join(ROOT,"examples","operation-contract.example.json")))
for p in oc["preconditions"]["predicates"]: env.compile(p)
st={"state":{"vendor":{"status":"approved"},"invoice":{"status":"issued","open_amount":{"value":"31400.00","currency":"USD"}},"payment":{"status":"draft","amount":{"value":"31400.00","currency":"USD"}}}}
print("preconditions hold:", all(bool(evaluate(p,st)) for p in oc["preconditions"]["predicates"]))
st["state"]["invoice"]["open_amount"]["value"]="0.00"   # PAY-901 in flight → open amount excludes it → PAY-902 refused
print("second payment of same invoice allowed:", all(bool(evaluate(p,st)) for p in oc["preconditions"]["predicates"]))
sys.exit(0 if ok else 1)
