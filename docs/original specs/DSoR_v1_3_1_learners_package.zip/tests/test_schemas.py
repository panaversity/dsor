import json, glob, copy, sys, os
ROOT=os.path.join(os.path.dirname(os.path.abspath(__file__)),"..")
from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource
schemas={}
for f in glob.glob(os.path.join(ROOT,"schemas","*.json")):
    s=json.load(open(f)); Draft202012Validator.check_schema(s); schemas[s["title"]]=s
reg=Registry().with_resources([(s["$id"],Resource.from_contents(s)) for s in schemas.values()])
def V(name): return Draft202012Validator(schemas[name],registry=reg,format_checker=FormatChecker())
H="sha256:9f2c1e7ab4d0"
corr={"request_id":"req_1","trace_id":"tr_9","tenant_id":"org_456","agent_id":"accounts-payable-fte"}
ident={"mode":"unattended","subject":"user_123","actor_chain":["accounts-payable-fte"],"subject_authority":{"source":"role_source","as_of":"2026-09-20T08:45:00Z"}}
auth={"system":"ksor","uri":"ksor://org_456/finance/payment-approval-policy","rule":"high-value-payment","version":4,"content_hash":H}
secctx={"identity_mode":"unattended","subject":"user_123","subject_type":"human","actor_chain":["accounts-payable-fte"],"active_tenant":"org_456","delegation":"del_100",
  "token_scopes":["invoice:read","vendor:read","payment:create","payment:execute"],"subject_authority":{"source":"role_source","as_of":"2026-09-20T08:45:00Z"}}
PAY="dsor://org_456/payment/PAY-901"; INV="dsor://org_456/invoice/INV-1008"; VEN="dsor://org_456/vendor/VENDOR-44"; PROP="dsor://org_456/proposal/prop_123"
E={}
E["security-context"]=secctx
E["operation-contract"]={"id":"payment.execute","version":1,"kind":"command","effect":"destructive",
 "input":{"schema":"PaymentExecutionRequest"},"output":{"schema":"PaymentExecutionResult"},
 "authorization":{"permission":"payment:execute","approve_permission":"payment:approve"},
 "tenancy":{"required":True},"delegation":{"required":True},"idempotency":{"required":True},"concurrency":{"strategy":"optimistic"},
 "execution":{"semantics":"non_compensatable"},"risk":{"level":"high"},
 "bind":{"payment":"input.payment","invoice":"state.payment.invoice","vendor":"state.payment.vendor"},
 "preconditions":{"freshness":"current","predicates":['state.vendor.status == "approved"','state.invoice.status == "issued"','state.payment.status == "draft"','dsor_covers(state.invoice.open_amount, state.payment.amount)']},
 "in_flight":{"exclusive_over":["payment"],"hold_on_unknown":["payment","invoice"]},
 "controls":["high-value-payment","approved-vendors-only"],"sod":{"incompatible_with":["proposal.approve"]},
 "audit":{"level":"full"},"connector_requirements":{"downstream_idempotency_or_outcome_lookup":True}}
E["control"]={"id":"high-value-payment","version":8,"status":"active","operation":"payment.execute",
 "condition":'dsor_exceeds(state.payment.amount, dsor_money("25000", "USD"))',
 "effect":{"require_approval":{"role":"CFO","quorum":1}},"authority":auth,"owner":"user_900","compiled_by":"policy-compiler-fte","reviewed_by":"user_900",
 "on_stale":"require_approval","stale_grace":"P7D","effective_from":"2026-09-01T00:00:00Z",
 "tests":[{"state":{"payment":{"amount":{"value":"25000.00","currency":"USD"}}},"expect":"ALLOW"},
          {"state":{"payment":{"amount":{"value":"25000.01","currency":"USD"}}},"expect":"REQUIRE_APPROVAL"},
          {"state":{"payment":{"amount":{"value":"50000000.00","currency":"PKR"}}},"rates":{"PKR":"280"},"expect":"REQUIRE_APPROVAL"},
          {"state":{"payment":{"amount":{"value":"6000000.00","currency":"PKR"}}},"rates":{"PKR":"280"},"expect":"ALLOW"},
          {"state":{"payment":{"amount":{"value":"100.00","currency":"XXX"}}},"expect":"REQUIRE_APPROVAL"}]}
E["delegation"]={"id":"del_100","tenant":"org_456","delegator":"user_123","delegate":"accounts-payable-fte","modes":["on_behalf_of","unattended"],
 "permissions":["invoice:read","vendor:read","payment:create","payment:execute"],
 "constraints":{"per_transaction_limit":{"value":"50000","currency":"USD"},"cumulative_limits":[{"window":"P1D","amount":{"value":"200000","currency":"USD"}}],
   "counterparties":"approved_vendors_only","time_window":{"days":["mon","tue","wed","thu","fri"],"hours":"08:00-18:00","tz":"Asia/Karachi"}},
 "subdelegation":{"allowed":False},"status":"active","expires_at":"2026-12-31T23:59:59Z"}
E["proposal"]={"uri":PROP,"tenant":"org_456","operation":"payment.execute@1","mode":"execute","state":"PENDING_APPROVAL",
 "payload":{"payment":PAY},"payload_hash":H,"resources":[PAY,INV,VEN],"requester":secctx,"idempotency_key":"idem_789",
 "requires":[{"control":"high-value-payment","control_version":8,"approval":{"role":"CFO","quorum":1}}],
 "reservation":{"limit":"del_100/P1D","amount":{"value":"31400.00","currency":"USD"},"state":"held"},
 "created_at":"2026-09-19T22:00:00Z","expires_at":"2026-09-22T22:00:00Z",
 "transitions":[{"to":"PROPOSED","at":"2026-09-19T22:00:00Z","actor":"accounts-payable-fte","cause":"payment.execute invoked"},
                {"from":"PROPOSED","to":"PENDING_APPROVAL","at":"2026-09-19T22:00:00Z","actor":"dsor","cause":"high-value-payment@8 REQUIRE_APPROVAL"}]}
E["approval"]={"id":"apr_555","proposal":PROP,"operation":"payment.execute@1","tenant":"org_456","resources":[PAY,INV,VEN],"payload_hash":H,"risk":"high",
 "bound_state":{"mode":"predicate","versions":{PAY:2,INV:18,VEN:6}},
 "satisfies":[{"control":"high-value-payment","version":8,"requirement":{"role":"CFO","quorum":1}}],
 "approvers":[{"principal":"cfo_100","basis":"role:CFO","authn":{"acr":"mfa","at":"2026-09-20T07:41:00Z"}}],
 "sod_mode":"standard","status":"active","expires_at":"2026-09-21T07:41:00Z"}
E["result-envelope"]={"outcome":"PENDING_APPROVAL","proposal":PROP,"payload_hash":H,"requires":[{"approval":{"role":"CFO","quorum":1},"control":"high-value-payment"}],
 "semantics":"non_compensatable","expires_at":"2026-09-22T22:00:00Z","correlation":corr}
E["error-envelope"]={"code":"OUTCOME_UNKNOWN","message":"Payment submission timed out; outcome is being reconciled.","retry":"after_reconciliation","proposal":PROP,"correlation":corr}
E["decision-bundle"]={"decision_id":"dec_123","operation":"payment.execute@1","proposal":PROP,"tenant":"org_456","identity":ident,
 "authority":{"delegation":"del_100","authorization":"ALLOW","controls":[{"id":"high-value-payment","version":8,"outcome":"REQUIRE_APPROVAL","satisfied_by":["apr_555"],"authority":auth}]},
 "money":{"conversions":[]},
 "state":[{"uri":PAY,"version":2,"observed_at":"2026-09-20T09:00:00Z","freshness":"CURRENT"},{"uri":INV,"version":18,"observed_at":"2026-09-20T09:00:00Z","freshness":"CURRENT"},{"uri":VEN,"version":6,"observed_at":"2026-09-20T09:00:00Z","freshness":"CURRENT"}],
 "approval":{"id":"apr_555","payload_hash":H,"approvers":["cfo_100"]},"sod_mode":"standard",
 "agent_asserted":{"skill":{"uri":"viking://agent/skills/vendor-payment","version":3,"hash":H},"purpose":"weekly payment run"},
 "execution":{"idempotency_key":"prop_123","connector":"postgres","semantics":"non_compensatable","intent_at":"2026-09-20T09:00:00.120Z","result":"committed","finalized_at":"2026-09-20T09:00:00.480Z"}}
E["audit-record"]={"record_id":"aud_9001","chain":"org_456/shard-0","sequence":4812,"previous_hash":H,"record_hash":H,"at":"2026-09-20T09:00:00.480Z","tenant":"org_456","kind":"decision",
 "identity":ident,"delegation":"del_100","operation":"payment.execute@1","resources":[PAY,INV,VEN],"payload_hash":H,"authorization":"ALLOW",
 "controls":[{"id":"high-value-payment","version":8,"outcome":"REQUIRE_APPROVAL","satisfied_by":["apr_555"],"authority":auth}],"approval":"apr_555",
 "connector":"postgres","semantics":"non_compensatable","result":"committed","decision_bundle":"dec_123","correlation":corr}
E["event"]={"event_id":"evt_77","type":"payment.executed","tenant":"org_456","resource":PAY,"ordering_key":3,"origin":"dsor","at":"2026-09-20T09:00:00.500Z","classification":"internal","correlation":corr}
E["connector"]={"id":"xero","contract_version":1,"region":"eu","external":True,
 "capabilities":{"transactions":False,"optimistic_concurrency":True,"downstream_idempotency":True,"outcome_lookup":True,"events":True,"batch":False,"row_level_security":False,"freshness":["current","bounded_staleness"]},
 "write_exclusivity":"shared","change_detection":{"method":"webhook","max_detection_lag_seconds":120}}
E["tenant-policy"]={"tenant":"org_456","money":{"control_currency":"USD","rate_source":"ecb-daily","max_rate_age":"P3D","on_unconvertible":"restrictive"},
 "role_source":{"kind":"scim","max_staleness":"PT1H"},
 "sod":{"owner_approval":{"enabled":False}},
 "egress":{"restricted":{"external_provider":"deny","in_tenant":"allow"},"confidential":{"external_provider":"allow_masked_identifiers","in_tenant":"allow"}},
 "residency":{"control_plane":["eu"],"audit":["eu"],"events":["eu"]}}
ok=True
for n,inst in E.items():
    errs=list(V(n).iter_errors(inst))
    assert inst==json.load(open(os.path.join(ROOT,"examples",f"{n}.example.json"))), n
    print(("PASS " if not errs else "FAIL ")+n, [e.message[:90] for e in errs][:3]); ok&=not errs
# negative tests: each mutation must be rejected
def mut(name, fn, why):
    global ok
    i=copy.deepcopy(E[name]); fn(i); bad=list(V(name).iter_errors(i))
    print(("REJECTED " if bad else "WRONGLY ACCEPTED ")+name+": "+why); ok&=bool(bad)
mut("delegation", lambda i: i["constraints"]["per_transaction_limit"].__setitem__("value",50000), "money value as a number")
mut("operation-contract", lambda i: i.pop("risk"), "contract without risk level")
mut("operation-contract", lambda i: i.pop("in_flight"), "non-compensatable command without in_flight rules")
mut("operation-contract", lambda i: i["authorization"].pop("approve_permission"), "non-compensatable command without approve_permission")
mut("control", lambda i: i.pop("owner"), "control without a human owner")
mut("control", lambda i: i.pop("reviewed_by"), "active control never reviewed")
mut("control", lambda i: i["authority"].pop("content_hash"), "KSoR authority without content hash")
mut("security-context", lambda i: i.pop("delegation"), "unattended request without delegation")
mut("security-context", lambda i: i["subject_authority"].__setitem__("source","token"), "unattended subject authority taken from a token")
mut("approval", lambda i: (i.__setitem__("risk","critical")), "critical approval with predicate binding")
mut("error-envelope", lambda i: i.__setitem__("retry","safe_same_key"), "OUTCOME_UNKNOWN marked retry-safe")
mut("connector", lambda i: i.pop("change_detection"), "shared connector without change detection")
mut("tenant-policy", lambda i: i["sod"]["owner_approval"].__setitem__("enabled",True), "owner-approval enabled without ceiling, cooling-off, notify")
mut("proposal", lambda i: i.__setitem__("uri","dsor://acme corp/proposal/x"), "malformed resource URI")
mut("result-envelope", lambda i: i.pop("proposal"), "PENDING_APPROVAL without proposal URI")
print("ALL OK" if ok else "PROBLEMS"); sys.exit(0 if ok else 1)
