# DSoR v1.4.0 (Learner's Edition) — specification package

New to this? Open the specification, read **Start here** (15 minutes), then follow
**Appendix D**, which builds a small DSoR in five stages. **Appendix E** has 23
questions with answers.

| Path | What it is |
|---|---|
| `DSoR_Specification_v1_4_0_Learners_Edition.md` | The whole specification in one file. Every section opens in plain words before its rules |
| `requirements.json` | Machine-readable registry of all 268 requirements: id, level, section, normative sentence |
| `schemas/*.schema.json` | Normative JSON Schemas (draft 2020-12), Appendix A. Unchanged since v1.3, so their URNs still say `1.3` |
| `examples/*.example.json` | One validated instance per schema, from the specification's running example |
| `tests/test_schemas.py` | Validates every example and checks that 15 invalid variants are rejected |
| `tests/test_control_cel.py` | Runs the `high-value-payment` control's test vectors and the `payment.execute` preconditions through a CEL evaluator |

```bash
pip install jsonschema cel-python
python tests/test_schemas.py
python tests/test_control_cel.py
```

## What changed since the v1.3.1 package

- The agent's notebook is split in two: **Graphiti for memory, OpenViking for skills
  and working files** (§33, §40).
- Two new STACK requirements in §34.6: **DSOR-CTX-07** (memory never stores
  operational state such as a status or a balance) and **DSOR-CTX-08** (every model a
  memory or context system uses is a model boundary, like the agent's own model).
- A new threat (T19), a new invariant row (§45), and questions 22 and 23.
- No other requirement changed and no schema changed.

This package is a standalone snapshot for reading and teaching. The source of truth,
with the TypeScript tests and the Claude Code setup, is
<https://github.com/panaversity/dsor>.
